#pragma once

#include "NovaCoreMenu.h"

namespace NovaCore
{
    NovaCoreMenu& GetMenu();
}
