#pragma once

#include <cstddef>
#include <string>
#include <vector>

enum class MenuTab
{
    Home = 0,
    Movement,
    Weapons
};

struct MenuItem
{
    std::string name;
    bool enabled = false;
};

struct HandAnchor
{
    float x = 0.0f;
    float y = 0.05f; // 5 cm above the hand
    float z = 0.0f;
};

class NovaCoreMenu
{
public:
    NovaCoreMenu();

    // Left Y toggles the menu.
    void SetLeftYPressed(bool pressed);

    // Generic navigation hooks for the host VR runtime.
    void MoveSelection(int direction);
    void SwitchTab(int direction);
    bool ActivateSelected();

    bool IsOpen() const;
    void SetOpen(bool open);

    void Update();

    void SetHandAnchor(const HandAnchor& anchor);
    const HandAnchor& GetHandAnchor() const;

    MenuTab GetTab() const;
    std::size_t GetSelectedIndex() const;

    const std::vector<MenuItem>& Items() const;
    const std::vector<MenuItem>& CurrentTabItems() const;

private:
    bool menuOpen = false;
    bool lastLeftY = false;
    HandAnchor anchor{};
    MenuTab currentTab = MenuTab::Home;
    std::size_t selectedIndex = 0;

    std::vector<MenuItem> homeItems;
    std::vector<MenuItem> movementItems;
    std::vector<MenuItem> weaponItems;

    void ToggleMenu();
    void ResetSelection();
};
