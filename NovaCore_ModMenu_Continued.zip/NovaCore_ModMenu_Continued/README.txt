NovaCore Mod Menu - Continued

Added:
- Left Y toggles the menu open/closed.
- Hand anchor defaults to 5 cm above the hand.
- Home tab.
- Movement tab: Fly, Platforms.
- Weapons tab: Infinite Ammo, Multiple Ammo, Max Shots.
- Selection navigation with MoveSelection().
- Tab navigation with SwitchTab().
- ActivateSelected() toggles a selected mod or opens a category.

Host VR runtime responsibilities:
- Read the Quest/VR controller state.
- Pass left-Y button state to SetLeftYPressed().
- Pass stick/d-pad navigation to MoveSelection()/SwitchTab().
- Render the menu at GetHandAnchor().

This is a standalone C++ menu/state library. It does not contain anti-cheat or integrity bypass code.
