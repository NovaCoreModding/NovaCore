#include "NovaCore.h"

namespace NovaCore
{
    NovaCoreMenu& GetMenu()
    {
        static NovaCoreMenu menu;
        return menu;
    }
}
