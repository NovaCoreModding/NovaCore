#include "NovaCoreMenu.h"

NovaCoreMenu::NovaCoreMenu()
{
    homeItems = {
        {"Movement", false},
        {"Weapons", false},
    };

    movementItems = {
        {"Fly", false},
        {"Platforms", false},
    };

    weaponItems = {
        {"Infinite Ammo", false},
        {"Multiple Ammo", false},
        {"Max Shots", false},
    };
}

void NovaCoreMenu::SetLeftYPressed(bool pressed)
{
    if (pressed && !lastLeftY)
    {
        ToggleMenu();
    }

    lastLeftY = pressed;
}

void NovaCoreMenu::ToggleMenu()
{
    menuOpen = !menuOpen;

    if (menuOpen)
    {
        ResetSelection();
    }
}

void NovaCoreMenu::SetOpen(bool open)
{
    menuOpen = open;

    if (menuOpen)
    {
        ResetSelection();
    }
}

bool NovaCoreMenu::IsOpen() const
{
    return menuOpen;
}

void NovaCoreMenu::Update()
{
    // Per-frame controller input and rendering are supplied by the host VR runtime.
}

void NovaCoreMenu::MoveSelection(int direction)
{
    const auto& items = CurrentTabItems();
    if (items.empty() || direction == 0)
        return;

    const auto count = items.size();

    if (direction > 0)
    {
        selectedIndex = (selectedIndex + 1) % count;
    }
    else
    {
        selectedIndex = (selectedIndex == 0) ? count - 1 : selectedIndex - 1;
    }
}

void NovaCoreMenu::SwitchTab(int direction)
{
    int tab = static_cast<int>(currentTab);
    tab += (direction > 0 ? 1 : (direction < 0 ? -1 : 0));

    if (tab < 0)
        tab = 2;
    if (tab > 2)
        tab = 0;

    currentTab = static_cast<MenuTab>(tab);
    ResetSelection();
}

bool NovaCoreMenu::ActivateSelected()
{
    auto& items = const_cast<std::vector<MenuItem>&>(CurrentTabItems());

    if (items.empty() || selectedIndex >= items.size())
        return false;

    // Home acts as a category selector.
    if (currentTab == MenuTab::Home)
    {
        if (selectedIndex == 0)
            currentTab = MenuTab::Movement;
        else if (selectedIndex == 1)
            currentTab = MenuTab::Weapons;

        ResetSelection();
        return true;
    }

    items[selectedIndex].enabled = !items[selectedIndex].enabled;
    return items[selectedIndex].enabled;
}

void NovaCoreMenu::SetHandAnchor(const HandAnchor& value)
{
    anchor = value;
}

const HandAnchor& NovaCoreMenu::GetHandAnchor() const
{
    return anchor;
}

MenuTab NovaCoreMenu::GetTab() const
{
    return currentTab;
}

std::size_t NovaCoreMenu::GetSelectedIndex() const
{
    return selectedIndex;
}

const std::vector<MenuItem>& NovaCoreMenu::CurrentTabItems() const
{
    switch (currentTab)
    {
    case MenuTab::Movement:
        return movementItems;
    case MenuTab::Weapons:
        return weaponItems;
    case MenuTab::Home:
    default:
        return homeItems;
    }
}

const std::vector<MenuItem>& NovaCoreMenu::Items() const
{
    return CurrentTabItems();
}

void NovaCoreMenu::ResetSelection()
{
    selectedIndex = 0;
}
