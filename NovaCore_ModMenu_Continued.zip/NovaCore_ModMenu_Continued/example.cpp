#include "NovaCore.h"

int main()
{
    auto& menu = NovaCore::GetMenu();

    // Example host-runtime wiring:
    menu.SetLeftYPressed(true);   // open
    menu.SetLeftYPressed(false);

    menu.MoveSelection(1);
    menu.ActivateSelected();

    return 0;
}
